import { Component, Input, OnInit } from '@angular/core';
import { Product } from '../models/products';

@Component({
  selector: 'app-product-card',
  template: `
  <div class="card" style="width: 20rem;">
    <div class="card-body">
      <h5 class="card-title">{{product.name}}</h5>
      <p class="card-text">{{product.description}}</p>
      <a [routerLink]="['/product',product.id]" class="card-link">Dettagli</a>

    </div>
  </div>

  `,
  styles: [
  ]
})
export class ProductCardComponent implements OnInit {
  @Input() product!: Product

  constructor() { }

  ngOnInit(): void {
  }

}
