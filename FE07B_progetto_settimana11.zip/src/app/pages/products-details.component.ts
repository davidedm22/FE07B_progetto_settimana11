import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Product } from '../models/products';
import { ApiService } from '../service/api.service';
import { CartService } from '../service/cart.service';

@Component({
  selector: 'app-products-details',
  template: `
   <div class="d-flex flex-column align-items-center mt-4">
     <h2 class="mb-4">Dettagli Prodotto</h2>
     <div *ngIf="product">
       <h3>{{product.name}}</h3>
       <h4>{{product.price}}</h4>
       <p>{{product.description}}</p>
       <button (click)="addToCart()" class="btn btn-primary">Aggiungi al carrello</button>

     </div>

   </div>
  `,
  styles: [
  ]
})
export class ProductsDetailsComponent implements OnInit {
  product:Product | undefined;

  constructor(
    private route:ActivatedRoute,
    private apiSrv: ApiService,
    private cartSrv: CartService
  ) { }

  ngOnInit(): void {
    this.route.params.subscribe(async (params)=>{
      const id = +params['id'];
      this.product = await this.apiSrv.getProduct(id).toPromise();
    });
  }
  addToCart(){
    this.cartSrv.addProduct(this.product as Product)
  }

}
