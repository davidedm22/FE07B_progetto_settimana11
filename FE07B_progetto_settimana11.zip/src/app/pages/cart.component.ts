import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Subscription } from 'rxjs';
import { Product } from '../models/products';
import { CartService } from '../service/cart.service';

@Component({
  template: `
    <div class="container mt-4">
      <ng-container *ngIf="cart && cart.length > 0; else elseTemplate">
        <h3>Articoli</h3>
        <ul class="list-group">
          <li *ngFor="let p of cart" class="list-group-item d-flex justify-content-between align-items-center">
            {{p.name}}
            <span class="badge bg-primary roundend-pill">{{p.price}}£</span>
          </li>
      </ul>
      <h3>completa l'ordine</h3>
      <form #form="ngForm" (ngSubmit)="submit(form)">
        <div class="form-group">
          <label for="name">Nome</label>
          <input ngModel name="name" class="form-control" id="name" type="text">
        </div>
        <div class="form-group">
          <label for="address">Indirizzo</label>
          <input ngModel name="address" class="form-control" id="address" type="text">
      </div>
      <button class="btn btn-primary" type="submit">Invia</button>
      </form>
</ng-container>
<ng-template #elseTemplate>
  <h2 class="text-center">Il carrello e vuoto</h2>
</ng-template>
 </div>

  `,
  styles: [
  ]
})
export class CartComponent implements OnInit {
  cart: Product[] | undefined;
  sub!: Subscription

  constructor(private cartSrv: CartService) { }

  ngOnInit(): void {
    this.cart = this.cartSrv.getCart();
    this.sub = this.cartSrv.subject.subscribe( tot =>{
      if (tot == 0){
        this.cart = undefined
      }
    })
  }


  submit(f:NgForm){

    this.cartSrv.clearCart()
  }
  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    this.sub.unsubscribe()
  }

}
