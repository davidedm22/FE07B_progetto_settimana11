import { Component, Input, OnInit } from '@angular/core';
import { ApiService } from '../service/api.service';
import  {Product } from '../models/products';
import { Subscription } from 'rxjs';


@Component({
  template: `
  <div class="container mt-4">
    <div class="row">
      <div class="col d-flex flex-column align-items-center">
        <app-product-card class="mb-4" [product]="p" *ngFor="let p of products">
  </app-product-card>
       </div>
    </div>
 </div>




  `,
  styles: [
  ]
})
export class ProductListComponent implements OnInit {

  products:Product[]| undefined
  sub!: Subscription

  constructor(private apiSrv : ApiService) { }

  ngOnInit(): void {
    this.sub = this.apiSrv.get()
    .subscribe(products =>{
      this.products = products;
    })
  }
  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    this.sub.unsubscribe()
  }

}
