import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Route } from '@angular/router';
import { NavbarComponent } from './navbar.component';


import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { ProductListComponent } from './pages/product-list.component';
import {HttpClientModule} from '@angular/common/http';
import { ProductsDetailsComponent } from './pages/products-details.component';
import { CartComponent } from './pages/cart.component';
import { ProductCardComponent } from './component/product-card.component'


const routes: Route[]=[
  {
    path: '',
    component: ProductListComponent
  },
  {
    path: 'cart',
    component: CartComponent
  },
  {
    path:'product/:id',
    component:ProductsDetailsComponent
  }

]

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    ProductListComponent,
    ProductsDetailsComponent,
    CartComponent,
    ProductCardComponent
],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(routes),
    HttpClientModule,
    FormsModule
],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
