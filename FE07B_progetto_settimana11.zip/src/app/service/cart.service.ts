import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { Product } from '../models/products';


@Injectable({
  providedIn: 'root'
})
export class CartService {
  private cart:Product[]= []
  subject = new Subject<number>()


  constructor() { }
  getCart(){
    return this.cart
  }
  addProduct(product:Product){
    this.cart = [...this.cart,product]
    this.subject.next(this.cart.length)
  }
  clearCart(){
    this.cart = []
    this.subject.next(0)
  }
}
